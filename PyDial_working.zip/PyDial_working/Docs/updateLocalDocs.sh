#!/bin/bash

cp -r ../_build /tools/WorldWideWeb/old/research/dialogue/LocalDocs/cued-python-doc/
